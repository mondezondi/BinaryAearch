/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javacomments;

/**
 *
 * @author Lenovo-User
 */
public class App {

    public static void main(String[] args) {
        //This is a comment//
        System.out.println("Hello World!");
    }
}
