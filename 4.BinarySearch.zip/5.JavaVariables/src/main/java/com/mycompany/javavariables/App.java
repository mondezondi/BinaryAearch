/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.javavariables;

/**
 *
 * @author Lenovo-User
 */
public class App {

    public static void main(String[] args) {
        
         String name = "John";
        System.out.println(name);
        
        int myNum = 5;
        float myfloatNum = 5.99f;
        char myLetter = 'D';
        boolean myBool = true;
        String myText = "Hello";  // Note: 'String' should start with an uppercase 'S'
        
        // Additional: Printing the variables to see their values
        System.out.println("My Number: " + myNum);
        System.out.println("My Float Number: " + myfloatNum);
        System.out.println("My Letter: " + myLetter);
        System.out.println("My Boolean: " + myBool);
        System.out.println("My Text: " + myText);
    }

    }
}
